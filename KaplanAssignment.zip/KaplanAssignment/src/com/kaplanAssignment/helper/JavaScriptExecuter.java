package com.kaplanAssignment.helper;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class JavaScriptExecuter {
	

	public  void ScrollAndClickOnElement(WebElement element, WebDriver driver) {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView()", element);
		System.out.println("Scrolled to the element.");
		element.click();
		System.out.println("The element has been clicked.");
		
	}
	
	
	
	public void scrollIntoView(WebElement element,WebDriver driver){
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView()",element);
		System.out.println("Scrolled to the element.");
	}
	
	
	
	
}
