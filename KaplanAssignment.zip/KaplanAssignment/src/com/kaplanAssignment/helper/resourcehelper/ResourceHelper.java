package com.kaplanAssignment.helper.resourcehelper;

public class ResourceHelper {
	
	public static String getResourcePath(String path) {
		String basePath=System.getProperty("user.dir");
		System.out.println("The path is: "+basePath+"\\"+path);
		return basePath+"\\"+path;
		
		
	}

}
