package com.kaplanAssignment.scripts;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.net.UrlChecker.TimeoutException;
import org.testng.annotations.Test;

import com.kaplanAssignment.excel.DataProviderClass;
import com.kaplanAssignment.testBase.TestBase;

public class Exercise1 extends TestBase {

	@Test(dataProvider = "TestData1", dataProviderClass = DataProviderClass.class)

	public void exercise1(String Full_Name, String Country_of_Study, String Course_of_Study,
			String Coborrower_Income, String Email_ID, String Residence_City,
			String Course_Name, String Required_Loan_Amount, String Mobile_Number, String Applicant_Income_Status) throws TimeoutException, InterruptedException {

		if(Full_Name==null){
			System.out.println("Skip");
		} 
		
		else {
			//Page load time out of 60 secs
			driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
			//Implicit wait of 60 secs
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			String url = "https://www.deal4loans.com/";
			driver.get(url);
			System.out.println("Navigating to Url: "+url);
			pageObject1.clickallAboutPersonalLoansImage();
			pageObject1.clickEducationLoan();
			pageObject1.applyForPersonalLoan(Full_Name, Country_of_Study, Course_of_Study, Coborrower_Income, Email_ID, Residence_City, Course_Name
					, Required_Loan_Amount, Mobile_Number, Applicant_Income_Status );
	        pageObject1.verifyThankYouMessage();
		}
		
	}
}
