package com.kaplanAssignment.scripts;

import org.testng.annotations.Test;

import com.kaplanAssignment.excel.DataProviderClass;
import com.kaplanAssignment.testBase.TestBase;

public class Exercise3 extends TestBase {
// Below is the url for Gmail 
	String url = "https://mail.google.com/mail/u/0/";

	// Please enter the Mailer name below..ex "Chacko, Denis"
	String name = "Chacko, Denis";
	// Please enter the subject of the mail u want to check
	String subjectContent = "This is Subject!";
	// Please enter the Body contents that u want to verify
	String bodyContent = "This is a body";

	@Test(dataProvider = "TestData2", dataProviderClass = DataProviderClass.class)

	public void exercise3(String email, String password) throws InterruptedException {
		if (email == null) {
			System.out.println("Skipping this run.");
		} else {
			driver.get(url);
			System.out.println("Navigating to Url: "+url);
			pageObject3.loginToGmail(email, password);
			pageObject3.checkUnreadMail(name, subjectContent, bodyContent);
			pageObject3.signOut();
			pageObject3.changeAccount(driver);

		}

	}

}
