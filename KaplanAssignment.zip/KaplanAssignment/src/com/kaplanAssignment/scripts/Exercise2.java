package com.kaplanAssignment.scripts;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.kaplanAssignment.testBase.TestBase;

public class Exercise2 extends TestBase {
	String url = "";
	

	@Test

	public void exercise2() throws InterruptedException {

		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		String homePage = "http://www.codetraverse.com/";
		driver.get(homePage);
		Thread.sleep(1000);
		// Switching to the frame as all the links are inside a frame
		driver.switchTo().frame(1);
		List<WebElement> links = driver.findElements(By.xpath("//a"));
		//The size of links gives the total links 
		int size = links.size();
		System.out.println("The tolal links in the page: " + size);
		int count = 1;
		for (WebElement link : links) {
			url = link.getAttribute("href");
			System.out.println("Url: " + count + " " + url);
			verifyLink(url);
			count++;

		}

	}

	// The below function verifyLink(String urlLink) verifies any broken links and
	// return the server status.
	public static void verifyLink(String urlLink) {
		
		try {
			
			URL link = new URL(urlLink);
			
			HttpURLConnection httpConn = (HttpURLConnection) link.openConnection();
			
			httpConn.setConnectTimeout(5000);
			
			httpConn.connect();
			
			
			if (httpConn.getResponseMessage().contentEquals("OK")) {
				System.out.println("Response: " +httpConn.getResponseMessage()+". The response is valid.");
			}
			if (httpConn.getResponseMessage().contentEquals("Bad Request")) {
				System.out.println("Response: " +httpConn.getResponseMessage()+". The response is not valid.");
				
				
			}
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	

}
