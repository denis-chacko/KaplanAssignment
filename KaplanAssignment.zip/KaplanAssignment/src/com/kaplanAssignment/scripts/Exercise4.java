package com.kaplanAssignment.scripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.kaplanAssignment.testBase.TestBase;

public class Exercise4 extends TestBase {

	String url = "https://www.southwest.com";
	String ActualTitleFinalPage="Southwest Airlines - Passenger and Payment Information";

	@Test
	public void exercise4() throws InterruptedException {
		driver.get(url);
		pageObject4.searchForFlight("IND", "BZE");
		pageObject4.selectPriceAndContinue();
		pageObject4.scrollAndClickContinue();
		pageObject4.fillWhoSFlyingDetails("Denis", "Chacko", "03", "1994");
		
		String ExpectedTitle = driver.getTitle();
		Assert.assertEquals(ActualTitleFinalPage, ExpectedTitle);
		pageObject4.complete();
		
	}

}
