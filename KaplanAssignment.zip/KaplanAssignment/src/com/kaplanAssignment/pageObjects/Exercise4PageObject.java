package com.kaplanAssignment.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.kaplanAssignment.helper.DropDownHelper;
import com.kaplanAssignment.helper.JavaScriptExecuter;

public class Exercise4PageObject {
	private WebDriver driver;
	JavaScriptExecuter javaScriptExecuter = new JavaScriptExecuter();
	DropDownHelper dropDownHelper = new DropDownHelper(driver);

	@FindBy(xpath = "//input[@value = 'oneway' and @class = 'radio-button--input']")
	WebElement OneWayCheckBox;

	@FindBy(xpath = "//input[@id='LandingPageAirSearchForm_originationAirportCode']")
	WebElement departCheckBox;

	@FindBy(xpath = "//input[@id='LandingPageAirSearchForm_destinationAirportCode']")
	WebElement arriveCheckBox;

	@FindBy(xpath = "//button[@id='LandingPageAirSearchForm_submit-button']")
	WebElement searchButton;

	@FindBy(xpath = "//div[5]/div/button[1]")
	WebElement priceButton;

	@FindBy(xpath = "//button[@id='air-booking-product-1']")
	WebElement continueButton;

	@FindBy(xpath = "(.//*[normalize-space(text()) and normalize-space(.)='fare rules'])[2]/preceding::button[1]")
	WebElement continueButton2;

	@FindBy(xpath = "//div[@class='total-due-now--title']")
	WebElement totalDue;

	@FindBy(xpath = "//input[@id='passengerFirstName-0']")
	WebElement firstName;

	@FindBy(xpath = "//input[@id='passengerLastName-0']")
	WebElement lastName;

	@FindBy(xpath = "//*[@id='passengerDateOfBirthMonth-0']")
	WebElement month;
	@FindBy(xpath = "(//button[@type='button'])[28]")
	WebElement nov;

	@FindBy(xpath = "//input[@id='passengerDateOfBirthDay-0']")
	WebElement day;

	@FindBy(xpath = "//input[@id='passengerDateOfBirthYear-0']")
	WebElement year;

	@FindBy(xpath = "//input[@id='passengerGender-0']")
	WebElement gender;

	@FindBy(xpath = "(//button[@type='button'])[18]")
	WebElement male;

	@FindBy(xpath = "//input[@type = 'checkbox' and @aria-label = 'I do not wish to receive notifications.']")
	WebElement checkBox;

	public void searchForFlight(String departValue, String arriveValue) throws InterruptedException {
		Thread.sleep(3000);
		OneWayCheckBox.click();
		System.out.println("The one way radio button has been clicked.");
		departCheckBox.sendKeys(departValue);
		System.out.println("The depart value is entered: " + departValue);
		arriveCheckBox.sendKeys(arriveValue);
		System.out.println("The arrive value is entered: " + arriveValue);

		searchButton.click();
		System.out.println("The search button has been clicked");
		Thread.sleep(8000);

	}

	public void selectPriceAndContinue() throws InterruptedException {
		priceButton.click();
		System.out.println("The price has been selected.");
		Thread.sleep(2000);
		continueButton.click();
		System.out.println("The continue button has been clicked.");
	}

	public void scrollAndClickContinue() throws InterruptedException {
		Thread.sleep(3000);
		javaScriptExecuter.scrollIntoView(totalDue, driver);
		continueButton2.click();
		Thread.sleep(3000);

	}

	public Exercise4PageObject(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void fillWhoSFlyingDetails(String firstNameValue, String lastNameValue, String dayValue, String yearValue) {
		firstName.sendKeys(firstNameValue);
		System.out.println("The first Name has been entered: " + firstNameValue);
		lastName.sendKeys(lastNameValue);
		System.out.println("The first Name has been entered: " + lastNameValue);

		month.click();
		nov.click();

		day.sendKeys(dayValue);
		System.out.println("The day has been entered: " + dayValue);

		year.sendKeys(yearValue);
		System.out.println("The year has been entered: " + yearValue);

		gender.click();
		male.click();

	}

	public void complete() {
		System.out.println("The Flight booking is completed.");
		
	}

}
