package com.kaplanAssignment.pageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class Exercise3PageObject {
	
	
	@FindBy(xpath = "//input[@type='email']")
	WebElement emailTextBox;

	@FindBy(xpath = "//span[text()='Next']")
	WebElement nextButton;

	@FindBy(xpath = "//input[@type='password']")
	WebElement passwordTextBox;

	@FindBy(xpath = "//*[@class='zF']")
	List<WebElement> unreradMailList;

	@FindBy(xpath = "//span[@class='bqe']")
	List<WebElement> subject;

	@FindBy(xpath = "//div[@class='y6']//following-sibling::span")
	List<WebElement> body;

	@FindBy(xpath = "//*[@class='gb_ya gbii']")
	WebElement image;

	@FindBy(xpath = "//*[text()='Sign out']")
	WebElement signOut;



	public void loginToGmail(String id, String password) throws InterruptedException {
		emailTextBox.sendKeys(id);
		nextButton.click();
		Thread.sleep(3000);
		passwordTextBox.sendKeys(password);
		nextButton.click();
		Thread.sleep(3000);

	}

	public void checkUnreadMail(String myMailerValue, String subjectValue, String bodyContents) {
		List<WebElement> unreademeil = unreradMailList;

		String MyMailer = myMailerValue;

		for (int i = 0; i < unreademeil.size(); i++) {
			if (unreademeil.get(i).isDisplayed() == true) {

				if (unreademeil.get(i).getText().equals(MyMailer)) {
					System.out.println("Yes we have got mail from: " + MyMailer);
					if (subject.get(i).getText().equals(subjectValue)) {
						System.out.println("The subject is as expected: " + subjectValue);
						if (body.get(i - 1).getText().contains(bodyContents)) {
							System.out.println("The contents in the body is as expected: " + body.get(i - 1).getText());
						} else {
							System.out.println("Please check the body contents: " + body.get(i).getText());
						}
					} else {
						System.out.println("Please check the subject");
					}

					break;
				} else {
					System.out.println("No mail from: " + MyMailer);
				}
			}
		}
	}

	public Exercise3PageObject(WebDriver driver) {
		PageFactory.initElements(driver, this);

	}

	public void signOut() throws InterruptedException {
		image.click();
		Thread.sleep(2000);
		signOut.click();
		System.out.println("Signing off.");

	}

	public void changeAccount(WebDriver driver) throws InterruptedException {

		 driver.manage().deleteAllCookies();

	}

}
