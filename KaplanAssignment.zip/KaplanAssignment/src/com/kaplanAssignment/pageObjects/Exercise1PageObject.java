package com.kaplanAssignment.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.kaplanAssignment.helper.DropDownHelper;
import com.kaplanAssignment.helper.JavaScriptExecuter;
import com.kaplanAssignment.testBase.TestBase;

public class Exercise1PageObject {

	TestBase test = new TestBase();
	private WebDriver driver;
	JavaScriptExecuter javaScriptExecuter = new JavaScriptExecuter();
	DropDownHelper dropDownHelper = new DropDownHelper(driver);

	// The below Xpath is for All About Personal Loans Image

	@FindBy(xpath = "//div[@class='roundboximage3']")
	WebElement allAboutPersonalLoansImage;

	// The below xpath is Education Loan dropdown

	@FindBy(xpath = "//li[6]/a/span")
	WebElement educationLoanDrpDwn;

	// The below xpath is Education Loan dropdown

	@FindBy(xpath = "//a[@href = 'https://www.deal4loans.com/loans/education-loan/education-loan-student-loan/']")
	WebElement educationLoantab;

	@FindBy(xpath = "//input[@name = 'Name' and @class = 'd4l-input']")
	WebElement fullName;

	@FindBy(xpath = "//select[@name='Country']")
	WebElement countryOfStudyDrpDown;

	@FindBy(xpath = "//select[@name='Course']")
	WebElement courseOfStudyDrpDown;

	@FindBy(xpath = " //input[@id='Coborrower_Income']")
	WebElement coborrower_Income;

	@FindBy(xpath = "//input[@name = 'Email' and @class = 'd4l-input']")
	WebElement emailId;

	@FindBy(xpath = "//select[@name = 'City' and @class = 'd4l-select']")
	WebElement residenceCity;

	@FindBy(xpath = "//input[@name = 'Course_Name' and @class = 'd4l-input']")
	WebElement courseName;

	@FindBy(xpath = "//input[@name = 'Loan_Amount' and @class = 'd4l-input']")
	WebElement requiredoan;

	@FindBy(xpath = "//input[@name = 'Phone' and @class = 'd4l-input']")
	WebElement mobileNo;

	@FindBy(xpath = "//select[@name = 'Employment_Status']")
	WebElement appIncomeStatusDrpdown;

	@FindBy(xpath = "//input[@name= 'accept' and @class='custom_checkbox']")
	WebElement accept;

	@FindBy(xpath = "//button[@id= 'education_loan_btn']")
	WebElement getQuoteButton;

	@FindBy(xpath = "//div[@id='txt']")
	WebElement quoteText;

	//

	public void clickallAboutPersonalLoansImage() throws InterruptedException {
		Thread.sleep(3000);
		javaScriptExecuter.ScrollAndClickOnElement(allAboutPersonalLoansImage,driver);
		System.out.println("All about personal loans has been clicked.");
		Thread.sleep(3000);

	}

	public void clickEducationLoan() throws InterruptedException {
		educationLoanDrpDwn.click();
		System.out.println("Education loan drop down has been selected");
		Thread.sleep(3000);
		educationLoantab.click();
		System.out.println("Education loan tab has been clicked.");
		Thread.sleep(2000);
	}

	

	public void applyForPersonalLoan(String fullNameValue, String countryOfStudyValue, String courseOfStudyValue, String coIncome,
			String email, String residenceCityValue, String courseNameValue, String requiredLoanValue, String mobNo,
			String appIncomeValue) throws InterruptedException {
		javaScriptExecuter.scrollIntoView(fullName,driver);
		Thread.sleep(2000);
		fullName.sendKeys(fullNameValue);
		System.out.println("Full Name has been entered: "+fullNameValue);
		dropDownHelper.selectUsingVisibleText(countryOfStudyDrpDown, countryOfStudyValue);
		System.out.println("The country of study has been seleceted"+countryOfStudyValue);
		dropDownHelper.selectUsingVisibleText(courseOfStudyDrpDown, courseOfStudyValue);
		System.out.println("The course of study has been seleceted"+courseOfStudyValue);

		coborrower_Income.sendKeys(coIncome);
		System.out.println("Co-borrower's income has been entered: "+coIncome);
		emailId.sendKeys(email);
		System.out.println("Email has been entered: "+email);
		dropDownHelper.selectUsingVisibleText(residenceCity, residenceCityValue);
		System.out.println("The residence city has been seleceted"+residenceCityValue);
		courseName.sendKeys(courseNameValue);
		System.out.println("Course name has been entered: "+courseNameValue);
		requiredoan.sendKeys(requiredLoanValue);
		System.out.println("Required loan has been entered: "+requiredLoanValue);
		mobileNo.sendKeys(mobNo);
		System.out.println("Mobile No has been entered: "+mobNo);
		
		dropDownHelper.selectUsingVisibleText(appIncomeStatusDrpdown, appIncomeValue);
		
		System.out.println("Application income value: "+appIncomeValue);
		accept.click();
		
		System.out.println("Accept check box has been entered.");
		

		getQuoteButton.click();
		System.out.println("Get quote button has been clicked.");

	}

	public void verifyThankYouMessage() {
		try {
			String actualText = quoteText.getText();
			String ExpectedText = "Thanks for applying Education Loan through Deal4loans.com. You will get a call from us, for information and rates.";
			Assert.assertEquals(actualText, ExpectedText);
			System.out.println("The actual text: " + actualText);
		}catch (Exception e) {
			System.out.println("The user has already applied for loan. Please enter a new user.");
		}
		
	}
	
	public Exercise1PageObject(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

}
