package com.kaplanAssignment.excel;

import org.testng.annotations.DataProvider;

import com.kaplanAssignment.helper.resourcehelper.ResourceHelper;

public class DataProviderClass {

	//The below is the data providor for Excercise 1
	@DataProvider(name = "TestData1")
	public static Object[][] getdata() throws Exception {

		String ExcelPath = ResourceHelper.getResourcePath("resources/excelFiles/TestData.xls");
		ExcelHelper excel = new ExcelHelper(ExcelPath);

		int row = excel.getRowCountByIndex(0);

		Object[][] data = new Object[row][10];

		for (int i = 1; i < row; i++) {

			data[i][0] = excel.getCellDataBySheetIndex(0, i, 0);// Full_Name
			data[i][1] = excel.getCellDataBySheetIndex(0, i, 1);// Country_of_Study
			data[i][2] = excel.getCellDataBySheetIndex(0, i, 2);// Course_of_Study
			data[i][3] = excel.getCellDataBySheetIndex(0, i, 3);// Co-borrower�s_ Income
			data[i][4] = excel.getCellDataBySheetIndex(0, i, 4);// Email_ID
			data[i][5] = excel.getCellDataBySheetIndex(0, i, 5);// Residence_City
			data[i][6] = excel.getCellDataBySheetIndex(0, i, 6);// Course_Name
			data[i][7] = excel.getCellDataBySheetIndex(0, i, 7);// Required_Loan_Amount
			data[i][8] = excel.getCellDataBySheetIndex(0, i, 8);// Mobile_Number
			data[i][9] = excel.getCellDataBySheetIndex(0, i, 9);// Applicant�s_Income_Status

		}

		return data;

	}

	
	//The below is the Data provider for Gmail test
	@DataProvider(name = "TestData2")
	public static Object[][] getloginData() throws Exception {

		String ExcelPath = ResourceHelper.getResourcePath("resources/excelFiles/TestData2.xls");
		ExcelHelper excel = new ExcelHelper(ExcelPath);

		int row = excel.getRowCountByIndex(0);

		Object[][] data = new Object[row][2];

		for (int i = 1; i < row; i++) {

			data[i][0] = excel.getCellDataBySheetIndex(0, i, 0);// Email
			data[i][1] = excel.getCellDataBySheetIndex(0, i, 1);// Password

		}

		return data;

	}
	
	
	


}
