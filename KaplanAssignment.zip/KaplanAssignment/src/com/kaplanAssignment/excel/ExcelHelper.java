package com.kaplanAssignment.excel;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelHelper {

	public FileInputStream fis = null;
	public FileOutputStream fos = null;
	public Workbook workbook = null;
	public Sheet sheet = null;
	public Row row = null;
	public Cell cell = null;
	public String excelPath;

	public ExcelHelper(String excelPath) throws Exception {

		fis = new FileInputStream(excelPath);

		// Create Workbook instance for input stream

		if (excelPath.toLowerCase().endsWith("xlsx")) {
			workbook = new XSSFWorkbook(fis);
			System.out.println("The file is of type .XLSX");
		} else if (excelPath.toLowerCase().endsWith("xls")) {
			workbook = new HSSFWorkbook(fis);
			System.out.println("The file is of type .XLS");
		}

		fis.close();
	}

	
	public int getRowCountByIndex(int sheetIndex) {
		int row = workbook.getSheetAt(sheetIndex).getLastRowNum();
		row = row + 1;

		return row;

	}
public String getCellDataBySheetIndex(int sheetindex, int rowNo, int colNo) {
		
		sheet = workbook.getSheetAt(sheetindex);

		row = sheet.getRow(rowNo);
		cell = row.getCell(colNo);
		String cellValue = null;

		if (cell == null) {
			cellValue = "";
			//System.out.println("The Cell is Blank!");

		} else
			switch (cell.getCellTypeEnum()) {
			case STRING:
				if (cell == null) {
					cellValue = "";
				}
				cellValue = cell.getRichStringCellValue().getString();
				//System.out.println("The Cell is a String!");
				break;
			case NUMERIC:
				int value = (int) cell.getNumericCellValue();
				cellValue = String.valueOf(value);
		

				if (DateUtil.isCellDateFormatted(cell)) {
					SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
					cellValue = dateFormat.format(cell.getDateCellValue());
					
				}
				break;
			case BOOLEAN:
				cellValue = String.valueOf(cell.getBooleanCellValue());
				
				break;
			case FORMULA:
				cellValue = cell.getCellFormula();
			
				break;
			case BLANK:
				cellValue = "";
				
				break;
			default:
				System.out.println("No such Value!");
			}
		return cellValue;

	}
	
	
	
	

}
