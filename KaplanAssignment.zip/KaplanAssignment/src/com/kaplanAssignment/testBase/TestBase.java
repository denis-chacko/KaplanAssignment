package com.kaplanAssignment.testBase;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import com.kaplanAssignment.helper.resourcehelper.ResourceHelper;
import com.kaplanAssignment.pageObjects.Exercise1PageObject;
import com.kaplanAssignment.pageObjects.Exercise3PageObject;
import com.kaplanAssignment.pageObjects.Exercise4PageObject;

public class TestBase {

	public WebDriver driver;

	protected Exercise1PageObject pageObject1;
	protected Exercise3PageObject pageObject3;
	protected Exercise4PageObject pageObject4;
	@BeforeTest
	public void beforeTest() throws Exception {

		System.setProperty("webdriver.chrome.driver",
				ResourceHelper.getResourcePath("resources/driver/chromedriver.exe"));
		
		
		
		driver = new ChromeDriver();
		
		
		
		pageObject1 = new Exercise1PageObject(driver);
		pageObject3=new Exercise3PageObject(driver);
		pageObject4=new Exercise4PageObject(driver);
	}

	@BeforeClass

	public void beforeClass() {
		driver.manage().window().maximize();

	}

	@AfterMethod
	public void afterMethod(ITestResult result) throws IOException {
		if (result.getStatus() == ITestResult.FAILURE) {
			System.out.println("Test Fail");

		} else if (result.getStatus() == ITestResult.SUCCESS) {
			System.out.println("Test Pass");
		} else if (result.getStatus() == ITestResult.SKIP) {
			System.out.println("Test Skip");
		}

	}

	@AfterSuite
	public void aftersuite() throws Exception {

		driver.quit();

	}

}